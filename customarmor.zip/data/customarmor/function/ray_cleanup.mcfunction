kill @s
