function customarmor:give/sword_neant
function customarmor:give/sword_zeus
function customarmor:give/pickaxe_divine
cpickaxe
caxe
function customarmor:give/bow_vent
function customarmor:give/helmet_poseidon
function customarmor:give/helmet_luffy
function customarmor:give/boots_maree
function customarmor:give/gardien
function customarmor:give/pegasus
function customarmor:give/cape_vent
function customarmor:give/amulette_berserker
function customarmor:give/steak_dore
function customarmor:give/pierre_chao
choe
